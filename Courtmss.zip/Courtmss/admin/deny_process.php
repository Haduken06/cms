<?php
include "../db_connect.php";
include "../email_notifier.php";

session_start();

$reservation_id = $_POST['reservation_id'];
$deny_reason = trim($_POST['deny_reason']);

if (empty($deny_reason)) {
    $_SESSION['error'] = "Denial reason is required.";
    header("Location: reservations.php");
    exit();
}

$conn->begin_transaction();

try {
    // Get reservation
    $get = $conn->prepare("SELECT * FROM reservations WHERE reservation_id = ?");
    $get->bind_param("i", $reservation_id);
    $get->execute();
    $row = $get->get_result()->fetch_assoc();

    if (!$row) {
        throw new Exception("Reservation not found");
    }

    $conn->query("SET FOREIGN_KEY_CHECKS = 0");

    // Insert into denied_bookings
    $insert = $conn->prepare("
        INSERT INTO denied_bookings 
        (
            reservation_id,
            fullname,
            email,
            phonenumber,
            purpose,
            date,
            start_time,
            end_time,
            booking_code,
            deny_reason,
            status
        ) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Denied')
    ");

    $insert->bind_param(
        "isssssssss",
        $row['reservation_id'],
        $row['fullname'],
        $row['email'],
        $row['phonenumber'],
        $row['purpose'],
        $row['date'],
        $row['start_time'],
        $row['end_time'],
        $row['booking_code'],
        $deny_reason
    );

    $insert->execute();

    // Delete from reservations
    $delete = $conn->prepare("DELETE FROM reservations WHERE reservation_id = ?");
    $delete->bind_param("i", $reservation_id);
    $delete->execute();

    $conn->query("SET FOREIGN_KEY_CHECKS = 1");
    $conn->commit();

    // Send email with reason
    sendReservationEmail(
        $row['email'],
        $row['fullname'],
        'DENIED',
        array_merge($row, ['deny_reason' => $deny_reason])
    );

    $_SESSION['deny'] = "Reservation for {$row['fullname']} has been denied.";
    header("Location: reservations.php");
    exit();

} catch (Exception $e) {
    $conn->rollback();
    $conn->query("SET FOREIGN_KEY_CHECKS = 1");

    $_SESSION['error'] = "Error: " . $e->getMessage();
    header("Location: reservations.php");
    exit();
}
?>
