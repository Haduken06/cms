<?php
session_start();
include "../db_connect.php";

if (!isset($_SESSION['username'])) {
    header("Location: ../index.php");
    exit();
}

$sql = "SELECT * FROM denied_bookings ORDER BY denied_at DESC";
$result = $conn->query($sql);
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Denied Bookings</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-50">
<div class="flex">

<!-- ================= SIDEBAR ================= -->
<div class="fixed top-0 left-0 flex h-screen w-64 flex-col bg-white shadow-lg">
    <div class="flex bg-gray-200 p-3 border-black border-b flex-col items-center">
    <?php 
        $baseUrl = "/courtmss/"; 

        $profilePic = (!empty($_SESSION['profile_pic'])) 
            ? $_SESSION['profile_pic'] 
            : $baseUrl . "uploads/profile_pic/default.jpg"; 
    ?>

    <img id="profile-pic"
         src="<?php echo htmlspecialchars($profilePic) . '?t=' . time(); ?>"
         class="w-20 h-20 rounded-full border-2 border-black cursor-pointer object-cover"
         title="Click to change profile picture"
         onerror="this.src='<?php echo $baseUrl; ?>assets/imgs/pfp.jpg';">

    <h2 class="text-xl font-semibold text-center text-gray-700 mt-2">
        Welcome <?php echo htmlspecialchars($_SESSION['fullname']); ?>!
    </h2>

    <form id="profileForm" enctype="multipart/form-data">
      <input type="file" id="fileInput" name="profile_pic" accept="image/*" hidden>
    </form>
</div>

    <div class="p-3 flex flex-col flex-1 overflow-y-auto">
        <a href="admin_board.php" class="flex items-center gap-3 rounded-lg px-3 py-2 mb-2 text-gray-700 hover:bg-gray-100">
            <i class="fas fa-tachometer-alt"></i> Dashboard
        </a>

        <a href="reservations.php" class="flex items-center gap-3 rounded-lg px-3 py-2 mb-2 text-gray-700 hover:bg-gray-100">
            <i class="fas fa-calendar-check"></i> Reservations
            <span id="count" class="ml-auto text-red-500 font-bold"></span>
        </a>

        <!-- Dropdown -->
        <div class="relative mb-2">
            <button class="flex items-center gap-3 w-full rounded-lg px-3 py-2 text-gray-700 hover:bg-gray-200"
                    type="button" data-bs-toggle="dropdown">
                <i class="fas fa-history"></i> History
                <i class="fas fa-caret-down ml-auto"></i>
            </button>
            <ul class="dropdown-menu w-full mt-1">
                <li><a class="dropdown-item" href="accepted.php"><i class="fas fa-check-circle me-2 text-green-500"></i> Accepted</a></li>
                <li class="bg-green-200">
                    <a class="dropdown-item" href="denied.php">
                        <i class="fas fa-ban me-2 text-yellow-500"></i> Denied
                    </a>
                </li>
                <li><a class="dropdown-item" href="cancelled.php"><i class="fas fa-times-circle me-2 text-red-500"></i> Cancelled</a></li>
            </ul>
        </div>

        <a href="users.php" class="flex items-center gap-3 rounded-lg px-3 py-2 mb-2 text-gray-700 hover:bg-gray-100">
            <i class="fas fa-users"></i> Users
        </a>

        <a href="settings.php" class="flex items-center gap-3 rounded-lg px-3 py-2 mb-2 text-gray-700 hover:bg-gray-100">
            <i class="fas fa-gear"></i> Settings
        </a>

        <a href="../logout.php" class="flex items-center gap-3 rounded-lg px-3 py-2 text-red-600 hover:bg-red-100 mt-auto">
            <i class="fas fa-right-from-bracket"></i> Logout
        </a>
    </div>
</div>

<!-- ================= MAIN ================= -->
<div class="ml-64 flex-1 bg-blue-50 p-6 min-h-screen">

<div class="flex justify-between items-center mb-4">
    <h1 class="text-3xl font-bold text-gray-800">Denied Bookings</h1>
    <button onclick="generatePDF('Denied_Bookings_Report')" class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded flex items-center gap-2 shadow-md transition">
        <i class="fas fa-file-pdf"></i> Export to PDF
    </button>
</div>

    <div id="pdf-table" class="bg-white shadow rounded-lg overflow-x-auto p-4">
        <table class="table table-bordered table-hover align-middle text-center">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Court</th>
                    <th>Date</th>
                    <th>Time Slot</th>
                    <th>Status</th>
                    <th>Denied At</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($result->num_rows > 0): ?>
                <?php $i = 1; ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $i++ ?></td>
                        <td><?= htmlspecialchars($row['fullname']) ?></td>
                        <td><?= htmlspecialchars($row['email']) ?></td>
                        <td><?= htmlspecialchars($row['phonenumber']) ?></td>
                        <td><?= htmlspecialchars($row['court_type']) ?></td>
                        <td><?= date("M d, Y", strtotime($row['date'])) ?></td>
                        <td><?= htmlspecialchars($row['time_slot']) ?></td>
                        <td>
                            <span class="badge bg-warning text-dark">
                                <?= htmlspecialchars($row['status']) ?>
                            </span>
                        </td>
                        <td><?= date("M d, Y h:i A", strtotime($row['denied_at'])) ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="9" class="text-center text-muted">
                        No denied bookings found.
                    </td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
function loadCount() {
    fetch("count_reservations.php")
        .then(res => res.text())
        .then(data => document.getElementById("count").innerHTML = data);
}
setInterval(loadCount, 2000);
loadCount();
</script>
<script>
const profilePic = document.getElementById("profile-pic");
const fileInput  = document.getElementById("fileInput");

// Open file picker
profilePic.addEventListener("click", () => {
    fileInput.click();
});

// Upload when file is selected
fileInput.addEventListener("change", () => {
    if (!fileInput.files.length) return;

    const formData = new FormData();
    formData.append("profile_pic", fileInput.files[0]);

    fetch("change_pic.php", {
        method: "POST",
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === "success") {
            // update image instantly
            profilePic.src = data.path + "?t=" + new Date().getTime();
            fileInput.value = ""; // allow same file again
        } else {
            alert(data.message);
        }
    })
    .catch(() => {
        alert("Upload failed. Please try again.");
    });
});
</script>
<script>
    function generatePDF(filename) {
    const element = document.getElementById('pdf-table');
    
    const opt = {
        margin:       0.3,
        filename:     filename + '.pdf',
        image:        { type: 'jpeg', quality: 0.98 },
        html2canvas:  { scale: 2, logging: false, useCORS: true },
        jsPDF:        { unit: 'in', format: 'letter', orientation: 'landscape' }
    };

    html2pdf().set(opt).from(element).save();
}
</script>
</body>
</html>
