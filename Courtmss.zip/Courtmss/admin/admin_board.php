<?php 
session_start();
include "../db_connect.php";

if (!isset($_SESSION['username']) || !isset($_SESSION['users_id'])) {
    header("Location: ../login.php");
    exit();
}

if (!isset($_SESSION['fullname'])) {
    $stmt = $conn->prepare("SELECT fullname, profile_pic FROM users WHERE users_id = ?");
    $stmt->bind_param("i", $_SESSION['users_id']);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $_SESSION['fullname'] = $res['fullname'] ?? 'Admin';
    $_SESSION['profile_pic'] = $res['profile_pic'] ?? '';
}

$year  = isset($_GET['year'])  ? (int)$_GET['year']  : (int)date('Y');
$month = isset($_GET['month']) ? (int)$_GET['month'] : (int)date('m');

$daysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year);

$total_res = $conn->query("
    SELECT 
        (SELECT COUNT(*) FROM accepted_bookings)  AS acc,
        (SELECT COUNT(*) FROM denied_bookings)    AS den,
        (SELECT COUNT(*) FROM cancelled_bookings) AS can,
        (SELECT COUNT(*) FROM users)              AS usr
")->fetch_assoc();

$accepted  = $total_res['acc'];
$denied    = $total_res['den'];
$cancelled = $total_res['can'];
$users     = $total_res['usr'];

$totalReservations = $accepted + $denied + $cancelled;

function getMonthlyData($conn, $table, $column, $month, $year, $days) {
    $data = array_fill(0, $days, 0);

    $sql = "
        SELECT DAY($column) AS day, COUNT(*) AS count
        FROM $table
        WHERE MONTH($column) = ? AND YEAR($column) = ?
        GROUP BY DAY($column)
    ";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $month, $year);
    $stmt->execute();

    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $data[$row['day'] - 1] = (int)$row['count'];
    }

    return $data;
}

$labels = range(1, $daysInMonth);

$acceptedData = getMonthlyData(
    $conn,
    'accepted_bookings',
    'created_at',
    $month,
    $year,
    $daysInMonth
);

$deniedData = getMonthlyData(
    $conn,
    'denied_bookings',
    'created_at',
    $month,
    $year,
    $daysInMonth
);

$cancelledData = getMonthlyData(
    $conn,
    'cancelled_bookings',
    'created_at',
    $month,
    $year,
    $daysInMonth
);

$usersData = getMonthlyData(
    $conn,
    'users',
    'created_at',
    $month,
    $year,
    $daysInMonth
);

$labelsJson     = json_encode($labels);
$acceptedJson   = json_encode($acceptedData);
$deniedJson     = json_encode($deniedData);
$cancelledJson  = json_encode($cancelledData);
$usersJson      = json_encode($usersData);

$calendarData = [];

$stmt = $conn->prepare("SELECT reservation_id, fullname, date, start_time, end_time FROM accepted_bookings WHERE MONTH(date) = ? AND YEAR(date) = ? ORDER BY date, start_time");

$stmt->bind_param("ii", $month, $year);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {

    $date = $row['date'];

    // ✅ Format start and end time
    $startFormatted = date("h:i A", strtotime($row['start_time']));
    $endFormatted   = date("h:i A", strtotime($row['end_time']));

    // Combine them
    $timeRange = $startFormatted . " - " . $endFormatted;

    // Determine AM or PM based on start time
    $hour = date("H", strtotime($row['start_time']));
    $period = ($hour < 12) ? "AM" : "PM";

    $firstname = explode(" ", trim($row['fullname']))[0];

    if (!isset($calendarData[$date])) {
        $calendarData[$date] = ["AM" => [], "PM" => []];
    }

    $calendarData[$date][$period][] = [
        "time" => $timeRange,
        "firstname" => $firstname
    ];
}

    $calendarJson = json_encode($calendarData);
?>


<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Admin Dashboard</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
<script src="https://cdn.tailwindcss.com"></script>
<style>
    .chart-box { position: relative; height: 320px; width: 100%; }
</style>
</head>
<body class="bg-gray-50">
<div class="flex">

<div class="fixed top-0 left-0 flex h-screen w-64 flex-col bg-white shadow-lg">
  <div class="flex bg-gray-200 p-3 border-black border-b flex-col items-center">
    <?php 
        // 1. Get the path from session
        $currentPic = $_SESSION['profile_pic'] ?? '';
        $defaultPic = "/courtmss/assets/imgs/pfp.jpg";

        // 2. Check if the session is empty; if so, use default
        // We use htmlspecialchars to prevent any path-based errors
        $displayPic = !empty($currentPic) ? $currentPic : $defaultPic;
    ?>
    <img id="profile-pic" 
         src="<?php echo htmlspecialchars($displayPic) . '?t=' . time(); ?>" 
         class="w-20 h-20 rounded-full border-2 border-black cursor-pointer object-cover" 
         title="Click to change profile picture" 
         onerror="this.src='/courtmss/assets/imgs/pfp.jpg';">
    
    <h2 class="text-xl font-semibold text-center text-gray-700 mt-2">
        Welcome <?php echo htmlspecialchars($_SESSION['fullname']); ?>!
    </h2>
    
    <form id="profileForm" enctype="multipart/form-data">
        <input type="file" id="fileInput" name="profile_pic" accept="image/*" hidden>
    </form>
</div>
  
  <div class="p-3 flex flex-col flex-1 overflow-y-auto">
    <a href="admin_board.php" class="flex items-center gap-3 rounded-lg px-3 py-2 mb-2 text-gray-700 bg-green-200"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="reservations.php" class="flex items-center gap-3 rounded-lg px-3 py-2 mb-2 text-gray-700 hover:bg-gray-200"><i class="fas fa-calendar-check"></i> Reservations <span id="count" class="ml-auto text-red-500 font-bold"></span></a>
    
    <div class="relative mb-2">
      <button class="flex items-center gap-3 w-full rounded-lg px-3 py-2 text-gray-700 hover:bg-gray-200 focus:outline-none" type="button" data-bs-toggle="dropdown"><i class="fas fa-history"></i> History <i class="fas fa-caret-down ml-auto"></i></button>
      <ul class="dropdown-menu w-full mt-1 border border-gray-200 rounded-lg shadow-sm">
        <li><a class="dropdown-item" href="accepted.php">Accepted</a></li>
        <li><a class="dropdown-item" href="denied.php">Denied</a></li>
        <li><a class="dropdown-item" href="cancelled.php">Cancelled</a></li>
      </ul>
    </div>

    <a href="users.php" class="flex items-center gap-3 rounded-lg px-3 py-2 mb-2 text-gray-700 hover:bg-gray-100"><i class="fas fa-users"></i> Users</a>
    <a href="settings.php" class="flex items-center gap-3 rounded-lg px-3 py-2 mb-2 text-gray-700"><i class="fas fa-gear"></i> Settings</a>
    <a href="../logout.php" class="flex items-center gap-3 rounded-lg px-3 py-2 text-red-600 hover:bg-red-100 mt-auto"><i class="fas fa-right-from-bracket"></i> Logout</a>
  </div>
</div>

<div class="ml-64 flex-1 bg-blue-50 p-6 min-h-screen">
  <h1 class="text-3xl font-bold text-gray-800">Dashboard</h1>
  
  <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mt-6">
    
    <div class="bg-white p-4 rounded-xl shadow-sm border-b-4 border-blue-500 flex justify-between items-center">
        <div>
            <h3 class='text-2xl font-bold'><?php echo $totalReservations; ?></h3>
            <p class="text-xs text-gray-500 uppercase font-semibold">Total Bookings</p>
        </div>
        <div class="bg-blue-100 p-3 rounded-full text-blue-500">
            <i class="fas fa-layer-group fa-lg"></i>
        </div>
    </div>

    <div class="bg-white p-4 rounded-xl shadow-sm border-b-4 border-green-500 flex justify-between items-center">
        <div>
            <h3 class='text-2xl font-bold'><?php echo $accepted; ?></h3>
            <p class="text-xs text-gray-500 uppercase font-semibold">Accepted</p>
        </div>
        <div class="bg-green-100 p-3 rounded-full text-green-500">
            <i class="fas fa-check-circle fa-lg"></i>
        </div>
    </div>

    <div class="bg-white p-4 rounded-xl shadow-sm border-b-4 border-yellow-500 flex justify-between items-center">
        <div>
            <h3 class='text-2xl font-bold'><?php echo $denied; ?></h3>
            <p class="text-xs text-gray-500 uppercase font-semibold">Denied</p>
        </div>
        <div class="bg-yellow-100 p-3 rounded-full text-yellow-500">
            <i class="fas fa-ban fa-lg"></i>
        </div>
    </div>

    <div class="bg-white p-4 rounded-xl shadow-sm border-b-4 border-red-500 flex justify-between items-center">
        <div>
            <h3 class='text-2xl font-bold'><?php echo $cancelled; ?></h3>
            <p class="text-xs text-gray-500 uppercase font-semibold">Cancelled</p>
        </div>
        <div class="bg-red-100 p-3 rounded-full text-red-500">
            <i class="fas fa-times-circle fa-lg"></i>
        </div>
    </div>

    <div class="bg-white p-4 rounded-xl shadow-sm border-b-4 border-indigo-500 flex justify-between items-center">
        <div>
            <h3 class='text-2xl font-bold'><?php echo $users; ?></h3>
            <p class="text-xs text-gray-500 uppercase font-semibold">Total Users</p>
        </div>
        <div class="bg-indigo-100 p-3 rounded-full text-indigo-500">
            <i class="fas fa-users fa-lg"></i>
        </div>
    </div>

</div>

    <!-- CALENDAR RESERVATIONS -->
<div class="bg-white p-6 rounded-lg shadow mt-8">

    <!-- Header -->
    <div class="flex justify-between items-center mb-4">
        <button onclick="changeMonth(-1)" class="px-3 py-1 bg-gray-200 rounded hover:bg-gray-300">
            ← Prev
        </button>

        <h2 class="text-xl font-semibold">
            <?php echo date("F Y", mktime(0,0,0,$month,1,$year)); ?>
        </h2>

        <button onclick="changeMonth(1)" class="px-3 py-1 bg-gray-200 rounded hover:bg-gray-300">
            Next →
        </button>
    </div>

    <!-- Weekdays -->
    <div class="grid grid-cols-7 text-center font-semibold mb-2">
        <div>Sun</div>
        <div>Mon</div>
        <div>Tue</div>
        <div>Wed</div>
        <div>Thu</div>
        <div>Fri</div>
        <div>Sat</div>
    </div>

    <!-- Calendar Grid -->
    <div id="calendar" class="grid grid-cols-7 gap-2 text-center"></div>
</div>

<!--DAILY ANALYTICS / PIE CHART-->
  <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-8">
<!--DAILY ANALYTICS-->
    <div class="lg:col-span-2 bg-white p-5 shadow rounded-lg flex flex-col">
      <div class="flex justify-between items-center mb-4">
          <h2 class="text-lg font-semibold text-gray-700">Daily Analytics</h2>
          
          <form method="GET" class="flex gap-2">
              <select name="month" onchange="this.form.submit()" class="border rounded px-2 py-1 text-xs bg-gray-50 cursor-pointer">
                  <?php for($m=1; $m<=12; $m++): $mv = str_pad($m,2,'0',STR_PAD_LEFT); ?>
                      <option value="<?= $mv ?>" <?= $mv == $month ? 'selected' : '' ?>><?= date('F', mktime(0,0,0,$m,1)) ?></option>
                  <?php endfor; ?>
              </select>
              <select name="year" onchange="this.form.submit()" class="border rounded px-2 py-1 text-xs bg-gray-50 cursor-pointer">
                  <?php for($y=2000; $y<=2100; $y++): ?>
                      <option value="<?= $y ?>" <?= $y == $year ? 'selected' : '' ?>><?= $y ?></option>
                  <?php endfor; ?>
              </select>
          </form>
      </div>
      <div class="chart-box">
          <canvas id="statusChart"></canvas>
      </div>
    </div>

                           
    <!--PIE CHART-->             
    <div class="bg-white p-5 shadow rounded-lg flex flex-col items-center">
      <h2 class="text-lg font-semibold text-gray-700 mb-4">Overall Distribution</h2>
      <div class="chart-box">
          <canvas id="pieChart"></canvas>
      </div>
    </div>       
  </div>

</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
const ctxLine = document.getElementById('statusChart').getContext('2d');
new Chart(ctxLine, {
    type: 'line',
    data: {
        labels: <?php echo $labelsJson; ?>,
        datasets: [
            { label: 'Accepted', data: <?php echo $acceptedJson; ?>, borderColor: 'green', tension: 0.3, fill: false },
            { label: 'Denied', data: <?php echo $deniedJson; ?>, borderColor: 'orange', tension: 0.3, fill: false },
            { label: 'Cancelled', data: <?php echo $cancelledJson; ?>, borderColor: 'red', tension: 0.3, fill: false },
            { label: 'Users', data: <?php echo $usersJson; ?>, borderColor: 'blue', tension: 0.3, fill: false }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { position: 'top', labels: { boxWidth: 12 } } },
        scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }
    }
});

const ctxPie = document.getElementById('pieChart').getContext('2d');
new Chart(ctxPie, {
    type: 'pie',
    data: {
        labels: ['Accepted', 'Denied', 'Cancelled', 'Users'],
        datasets: [{
            data: [<?php echo "$accepted, $denied, $cancelled, $users"; ?>],
            backgroundColor: ['green', 'orange', 'red', 'blue']
        }]
    },
    options: { responsive: true, maintainAspectRatio: false }
});

function loadCount() {
    fetch('count_reservations.php').then(r => r.text()).then(c => { document.getElementById('count').innerText = c; });
}
setInterval(loadCount, 2000); loadCount();

const pic = document.getElementById("profile-pic"), input = document.getElementById("fileInput");
pic.onclick = () => input.click();
input.onchange = () => {
    const fd = new FormData(); fd.append("profile_pic", input.files[0]);
    fetch("change_pic.php", { method: "POST", body: fd })
    .then(r => r.json()).then(d => {
        if (d.status === "success") { pic.src = d.path + "?t=" + Date.now(); }
        else { alert(d.message); }
    });
};
</script>
<script>
const calendarData = <?php echo $calendarJson; ?>;
let year = <?php echo $year; ?>;
let month = <?php echo $month; ?>;

const calendar = document.getElementById("calendar");

function buildCalendar() {

    calendar.innerHTML = "";

    const firstDay = new Date(year, month - 1, 1).getDay();
    const daysInMonth = new Date(year, month, 0).getDate();

    const today = new Date();
    const todayStr = today.toISOString().split('T')[0];

    for (let i = 0; i < firstDay; i++) {
        const empty = document.createElement("div");
        calendar.appendChild(empty);
    }

    for (let day = 1; day <= daysInMonth; day++) {

        const dateStr = `${year}-${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}`;

        const count = calendarData[dateStr]
            ? (calendarData[dateStr].AM.length + calendarData[dateStr].PM.length)
            : 0;

        const div = document.createElement("div");

        div.className = `
            border rounded cursor-pointer relative
            transition-all duration-200
            p-2 min-h-[60px]
            text-sm
            hover:shadow-md hover:-translate-y-1
        `;

        if (count > 0) {
            div.classList.add("bg-blue-100", "border-blue-400", "hover:bg-blue-200");
        } else {
            div.classList.add("bg-white", "border-gray-300", "hover:bg-gray-100");
        }

        if (dateStr === todayStr) {
            div.classList.remove("bg-blue-100", "bg-white");
            div.classList.add(
                "bg-green-300",
                "border-green-500",
                "font-bold",
                "hover:bg-green-200"
            );
        }


        div.innerHTML = `
            <div class="text-base font-semibold">${day}</div>

            ${count > 0 ? `
                <span class="absolute top-1 right-1 bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                    ${count}
                </span>
            ` : ""}
        `;

        div.onclick = () => showModal(dateStr);

        calendar.appendChild(div);
    }
}

function showModal(dateStr) {

    const details = calendarData[dateStr];
    const amList = document.getElementById("modalAM");
    const pmList = document.getElementById("modalPM");

    amList.innerHTML = "";
    pmList.innerHTML = "";

    if (!details) {
        amList.innerHTML = "<li>No reservations</li>";
        pmList.innerHTML = "<li>No reservations</li>";
    } else {

        if (details.AM.length === 0)
            amList.innerHTML = "<li>No reservations</li>";
        else
            details.AM.forEach(r => {
                amList.innerHTML += `<li>${r.time} - ${r.firstname}</li>`;
            });

        if (details.PM.length === 0)
            pmList.innerHTML = "<li>No reservations</li>";
        else
            details.PM.forEach(r => {
                pmList.innerHTML += `<li>${r.time} - ${r.firstname}</li>`;
            });
    }

    new bootstrap.Modal(document.getElementById('reservationModal')).show();
}

function changeMonth(direction) {

    let newMonth = month + direction;
    let newYear = year;

    if (newMonth < 1) {
        newMonth = 12;
        newYear--;
    }

    if (newMonth > 12) {
        newMonth = 1;
        newYear++;
    }

    window.location.href = `?month=${newMonth}&year=${newYear}`;
}

buildCalendar();
</script>

<!-- Reservation Modal -->
<div class="modal fade" id="reservationModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Reservations</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">

        <h6 class="text-success">AM</h6>
        <ul id="modalAM" class="mb-3"></ul>

        <h6 class="text-primary">PM</h6>
        <ul id="modalPM"></ul>

      </div>
    </div>
  </div>
</div>

</body>
</html>