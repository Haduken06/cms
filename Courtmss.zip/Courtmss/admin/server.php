<?php
include "../db_connect.php";

header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');
header('Connection: keep-alive');
header('Access-Control-Allow-Origin: *');

while (true) {
    $query = "SELECT * FROM reservations ORDER BY reservation_id ASC";
    $result = $conn->query($query);

    $rows = "";

    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {

    $actionButtons = "";

    if ($row['status'] == 'PENDING') {

        $actionButtons = '
            <a href="accept_process.php?id=' . $row['reservation_id'] . '" 
               class="btn btn-success btn-sm"
               onclick="return confirm(\'Accept this reservation?\')">
               <i class="fas fa-check"></i>
            </a>

            <button class="btn btn-danger btn-sm"
                    onclick="openDenyModal(' . $row['reservation_id'] . ')">
                <i class="fas fa-ban"></i>
            </button>
        ';

    } else {
        $actionButtons = '<span class="text-muted">No Action</span>';
    }
    $rows .= "
    <tr>
        <td>" . htmlspecialchars($row['fullname']) . "</td>
        <td>" . htmlspecialchars($row['email']) . "</td>
        <td>" . htmlspecialchars($row['phonenumber']) . "</td>
        <td>" . htmlspecialchars($row['purpose']) . "</td>
        <td>" . date("m/d/y", strtotime($row["date"])) . "</td>
        <td>" . htmlspecialchars($row['start_time']) . "</td>
        <td>" . htmlspecialchars($row['end_time']) . "</td>
        <td>" . htmlspecialchars($row['booking_code']) . "</td>
        <td>" . date("m/d/y", strtotime($row["created_at"])) . "</td>
        <td>" . htmlspecialchars($row['status']) . "</td>
        <td>" . $actionButtons . "</td>
    </tr>";
}

    } else {
        $rows .= "<tr><td colspan='9'>No reservations found</td></tr>";
    }

    echo "data: " . json_encode($rows) . "\n\n";
    ob_flush();
    flush();

    sleep(2);
}
?>
