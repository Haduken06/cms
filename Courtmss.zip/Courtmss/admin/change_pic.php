<?php
session_start();
include "../db_connect.php";

header("Content-Type: application/json");

if (!isset($_SESSION['username'])) {
    echo json_encode(["status" => "error", "message" => "Unauthorized"]);
    exit;
}

if (!isset($_FILES['profile_pic'])) {
    echo json_encode(["status" => "error", "message" => "No file received"]);
    exit;
}

// 1. Define the physical path for moving the file
$uploadDir = __DIR__ . "/../uploads/profile_pic/";
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

$file = $_FILES['profile_pic'];
$ext  = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
$allowed = ['jpg', 'jpeg', 'png', 'jfif'];

if (!in_array($ext, $allowed)) {
    echo json_encode(["status" => "error", "message" => "Invalid file type"]);
    exit;
}

$newName  = "profile_" . $_SESSION['username'] . "_" . time() . "." . $ext;
$fullPath = $uploadDir . $newName;

if (move_uploaded_file($file['tmp_name'], $fullPath)) {
    
    // 2. Define the WEB path (This must match your folder structure)
    // Fixed from /cmsss-new/ to /courtmss/
    $dbPath = "/courtmss/uploads/profile_pic/" . $newName;

    $stmt = $conn->prepare("UPDATE users SET profile_pic=? WHERE username=?");
    $stmt->bind_param("ss", $dbPath, $_SESSION['username']);
    
    if($stmt->execute()) {
        $_SESSION['profile_pic'] = $dbPath; // Update session with the new path
        echo json_encode([
            "status" => "success",
            "path"   => $dbPath
        ]);
    } else {
        echo json_encode(["status" => "error", "message" => "Database update failed"]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Upload failed"]);
}
exit;