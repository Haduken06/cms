<?php
include "../db_connect.php";
include "../email_notifier.php";

$reservation_id = $_GET['id'];

$conn->begin_transaction();

try {
    $get = $conn->prepare("SELECT * FROM reservations WHERE reservation_id = ?");
    $get->bind_param("i", $reservation_id);
    $get->execute();
    $row = $get->get_result()->fetch_assoc();

    if (!$row) {
        throw new Exception("Reservation not found");
    }

    $conn->query("SET FOREIGN_KEY_CHECKS = 0");

    $insert = $conn->prepare("
        INSERT INTO accepted_bookings 
        (
            reservation_id,
            fullname,
            email,
            phonenumber,
            purpose,
            date,
            start_time,
            end_time,
            booking_code,
            status
        ) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'ACCEPTED')
    ");

    $insert->bind_param(
        "issssssss",
        $row['reservation_id'],
        $row['fullname'],
        $row['email'],
        $row['phonenumber'],
        $row['purpose'],
        $row['date'],
        $row['start_time'],
        $row['end_time'],
        $row['booking_code']
    );

    $insert->execute();

    $delete = $conn->prepare("DELETE FROM reservations WHERE reservation_id = ?");
    $delete->bind_param("i", $reservation_id);
    $delete->execute();

    $conn->query("SET FOREIGN_KEY_CHECKS = 1");

    $conn->commit();

    sendReservationEmail($row['email'], $row['fullname'], 'ACCEPTED', $row);

    session_start();
    $_SESSION['success'] = "Reservation for " . $row['fullname'] . " has been accepted successfully!";

    header("Location: reservations.php");
    exit();

} catch (Exception $e) {
    $conn->rollback();
    $conn->query("SET FOREIGN_KEY_CHECKS = 1");

    session_start();
    $_SESSION['error'] = "Error: " . $e->getMessage();
    header("Location: reservations.php");
    exit();
}
?>
