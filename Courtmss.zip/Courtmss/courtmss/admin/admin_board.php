<?php 
session_start();
include "../db_connect.php";

if(!isset($_SESSION['fullname'])){
    $stmt = $conn->prepare("SELECT fullname FROM users WHERE username = ?");
    $stmt->bind_param("s", $_SESSION['username']);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $_SESSION['fullname'] = $user['fullname'];
}

// total reservations
$sql = "SELECT 
            (SELECT COUNT(*) FROM accepted_bookings) +
            (SELECT COUNT(*) FROM denied_bookings) +
            (SELECT COUNT(*) FROM cancelled_bookings) AS total";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$totalReservations = $row['total'];

// total users
$sql = "SELECT COUNT(*) AS total FROM users";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$users = $row['total'];

// accepted, denied, cancelled counts
$accepted = $conn->query("SELECT COUNT(*) AS total FROM accepted_bookings")->fetch_assoc()['total'];
$denied = $conn->query("SELECT COUNT(*) AS total FROM denied_bookings")->fetch_assoc()['total'];
$cancelled = $conn->query("SELECT COUNT(*) AS total FROM cancelled_bookings")->fetch_assoc()['total'];

// charts
$year = date('Y');
$month = date('m');
$monthName = date('F');
$daysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year);
$labels = $acceptedData = $deniedData = $cancelledData = $usersData = [];

for($d = 1; $d <= $daysInMonth; $d++){
    $date = "$year-$month-" . str_pad($d,2,'0',STR_PAD_LEFT);
    $labels[] = str_pad($d,2,'0',STR_PAD_LEFT);

    $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM accepted_bookings WHERE DATE(accepted_at) = ?");
    $stmt->bind_param("s", $date); $stmt->execute(); $acceptedData[] = (int)$stmt->get_result()->fetch_assoc()['total'];

    $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM denied_bookings WHERE DATE(denied_at) = ?");
    $stmt->bind_param("s", $date); $stmt->execute(); $deniedData[] = (int)$stmt->get_result()->fetch_assoc()['total'];

    $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM cancelled_bookings WHERE DATE(cancelled_at) = ?");
    $stmt->bind_param("s", $date); $stmt->execute(); $cancelledData[] = (int)$stmt->get_result()->fetch_assoc()['total'];

    $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM users WHERE DATE(created_at) = ?");
    $stmt->bind_param("s", $date); $stmt->execute(); $usersData[] = (int)$stmt->get_result()->fetch_assoc()['total'];
}

$labelsJson = json_encode($labels);
$acceptedJson = json_encode($acceptedData);
$deniedJson = json_encode($deniedData);
$cancelledJson = json_encode($cancelledData);
$usersJson = json_encode($usersData);
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Admin Dashboard</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
<div class="flex">

<!-- Sidebar -->
<div class="fixed top-0 left-0 flex h-screen w-64 flex-col bg-white shadow-lg">
  <div class="flex bg-gray-200 p-3 border-black border-b flex-col items-center">
    <?php 
    $baseUrl = "/cmsss-new/"; 
    $profilePic = (!empty($_SESSION['profile_pic'])) 
        ? $_SESSION['profile_pic'] 
        : $baseUrl . "assets/imgs/pfp.jpg";
?>

    <img id="profile-pic"
     src="<?php echo $profilePic . '?t=' . time(); ?>"
     class="w-20 h-20 rounded-full border-3 border-black cursor-pointer object-cover"
     title="Click to change profile picture">

    <h2 class="text-xl font-semibold text-center text-gray-700 mt-2">
        Welcome <?php echo $_SESSION['fullname']; ?>!
    </h2>

    <form id="profileForm" enctype="multipart/form-data">
      <input type="file" id="fileInput" name="profile_pic" accept="image/*" hidden>
    </form>
  </div>


  <div class="p-3 flex flex-col flex-1 overflow-y-auto">
    <a href="#" class="flex items-center gap-3 rounded-lg px-3 py-2 mb-2 text-gray-700 bg-green-200">
      <i class="fas fa-tachometer-alt"></i> Dashboard
    </a>

    <a href="reservations.php" class="flex items-center gap-3 rounded-lg px-3 py-2 mb-2 text-gray-700 :bg-gray-200">
      <i class="fas fa-calendar-check"></i> Reservations 
      <span id="count" class="ml-12 text-red-500 text-l font-bold"></span>
    </a>

    <!-- History Dropdown -->
    <div class="relative mb-2">
      <button class="flex items-center gap-3 w-full rounded-lg px-3 py-2 text-gray-700 hover:bg-gray-200 focus:outline-none" type="button" data-bs-toggle="dropdown" aria-expanded="false">
        <i class="fas fa-history"></i> History <i class="fas fa-caret-down ml-auto"></i>
      </button>
      <ul class="dropdown-menu w-full mt-1 border border-gray-200 rounded-lg shadow-sm">
        <li><a class="dropdown-item" href="accepted.php"><i class="fas fa-check-circle me-2 text-green-500"></i>Accepted</a></li>
        <li><a class="dropdown-item" href="denied.php"><i class="fas fa-ban me-2 text-yellow-500"></i>Denied</a></li>
        <li><a class="dropdown-item" href="cancelled.php"><i class="fas fa-times-circle me-2 text-red-500"></i>Cancelled</a></li>
      </ul>
    </div>

    <a href="users.php" class="flex items-center gap-3 rounded-lg px-3 py-2 mb-2 text-gray-700 hover:bg-gray-100">
      <i class="fas fa-users"></i> Users
    </a>
    <a href="settings.php" class="flex items-center gap-3 rounded-lg px-3 py-2 mb-2 text-gray-700 hover:bg-gray-100">
      <i class="fas fa-gear"></i>Settings
    </a>
    <a href="../logout.php" class="flex items-center gap-3 rounded-lg px-3 py-2 text-red-600 hover:bg-red-100 mt-auto">
      <i class="fas fa-right-from-bracket"></i> Logout
    </a>
  </div>
</div>

<!-- Main -->
<div class="ml-64 flex-1 bg-blue-50 p-6 min-h-screen">
  <h1 class="text-3xl font-bold text-gray-800">Dashboard</h1>
  
  <!-- Boxes -->
  <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-6">
    <div class="bg-white p-6 rounded-xl shadow-md flex items-center justify-between">
      <div>
        <h3 class='text-3xl font-bold text-blue-600'><?php echo $totalReservations; ?></h3>
        <p class="text-gray-600 font-medium">Total All Reservations</p>
      </div>
      <i class="fas fa-calendar-check text-blue-500 text-4xl"></i>
    </div>
    <div class="bg-white p-6 rounded-xl shadow-md flex items-center justify-between">
      <div>
        <h3 class='text-3xl font-bold text-green-600'><?php echo $users; ?></h3>
        <p class="text-gray-600 font-medium">Total Users</p>
      </div>
      <i class="fas fa-users text-green-500 text-4xl"></i>
    </div>
    <div class="bg-white p-6 rounded-xl shadow-md flex items-center justify-between">
      <div>
        <h3 class='text-3xl font-bold text-indigo-600'><?php echo $accepted; ?></h3>
        <p class="text-gray-600 font-medium">Total Accepted</p>
      </div>
      <i class="fas fa-check-circle text-indigo-500 text-4xl"></i>
    </div>
    <div class="bg-white p-6 rounded-xl shadow-md flex items-center justify-between">
      <div>
        <h3 class='text-3xl font-bold text-yellow-600'><?php echo $denied; ?></h3>
        <p class="text-gray-600 font-medium">Total Denied</p>
      </div>
      <i class="fas fa-ban text-yellow-500 text-4xl"></i>
    </div>
    <div class="bg-white p-6 rounded-xl shadow-md flex items-center justify-between">
      <div>
        <h3 class='text-3xl font-bold text-red-600'><?php echo $cancelled; ?></h3>
        <p class="text-gray-600 font-medium">Total Cancelled</p>
      </div>
      <i class="fas fa-times-circle text-red-500 text-4xl"></i>
    </div>
  </div>

  <!-- Charts -->
  <div class="flex flex-col lg:flex-row gap-5 mt-5">
    <div class="bg-white h-80 flex-1 p-5 shadow-lg rounded-lg">
      <h2 class="text-lg font-semibold text-gray-700 mb-2">Bookings Status - <?php echo $monthName; ?></h2>
      <canvas id="statusChart"></canvas>
    </div>
    <div class="bg-white h-80 flex-1 p-5 shadow-lg rounded-lg flex flex-col items-center justify-center">
      <h2 class="text-lg font-semibold text-gray-700 mb-4 text-center">Overall Records</h2>
      <div class="w-64 h-64">
        <canvas id="pieChart"></canvas>
      </div>
    </div>
  </div>
</div>

</div>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<!-- Reservation Count -->
<script>
function loadReservationCount() {
    fetch('count_reservations.php')
        .then(response => response.text())
        .then(count => {
            document.getElementById('count').innerText = count;
        })
        .catch(err => console.error(err));
}
loadReservationCount();
setInterval(loadReservationCount, 2000);
</script>

<!-- Charts -->
<script>
// line chart
const ctxLine = document.getElementById('statusChart').getContext('2d');
const statusChart = new Chart(ctxLine, {
    type: 'line',
    data: {
        labels: <?php echo $labelsJson; ?>,
        datasets: [
            { label: 'Accepted', data: <?php echo $acceptedJson; ?>, borderColor: 'green', fill: false, tension: 0.2, pointStyle: 'rect', pointRadius: 6 },
            { label: 'Denied', data: <?php echo $deniedJson; ?>, borderColor: 'orange', fill: false, tension: 0.2, pointStyle: 'rect', pointRadius: 6 },
            { label: 'Cancelled', data: <?php echo $cancelledJson; ?>, borderColor: 'red', fill: false, tension: 0.2, pointStyle: 'rect', pointRadius: 6 },
            { label: 'New Users', data: <?php echo $usersJson; ?>, borderColor: 'blue', fill: false, tension: 0.2, pointStyle: 'rect', pointRadius: 6 }
        ]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                position: 'top',
                align: 'start',
                labels: {
                    usePointStyle: true,
                    pointStyle: 'rect',
                    boxWidth: 20,
                    padding: 10,
                    font: {
                        size: 14,
                        weight: 'bold'
                    }
                }
            }
        },
        scales: {
            y: { beginAtZero: true }
        }
    }
});


// pie chart
const ctxPie = document.getElementById('pieChart').getContext('2d');
const pieChart = new Chart(ctxPie, {
    type: 'pie',
    data: {
        labels: ['Accepted', 'Denied', 'Cancelled', 'New Users'],
        datasets: [{
            data: [
                <?php echo $accepted; ?>,
                <?php echo $denied; ?>,
                <?php echo $cancelled; ?>,
                <?php echo $users; ?>
            ],
            backgroundColor: [
                'green',
                'orange',
                'red',
                'blue'
            ]
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                position: 'top',
                align: 'start',
                labels: {
                    usePointStyle: true,
                    pointStyle: 'rect',
                    boxWidth: 20,
                    padding: 12,
                    font: {
                        size: 14,
                        weight: 'bold'
                    }
                }
            }
        }
    }
});
</script>

<script>
const profilePic = document.getElementById("profile-pic");
const fileInput  = document.getElementById("fileInput");

// Open file picker
profilePic.addEventListener("click", () => {
    fileInput.click();
});

// Upload when file is selected
fileInput.addEventListener("change", () => {
    if (!fileInput.files.length) return;

    const formData = new FormData();
    formData.append("profile_pic", fileInput.files[0]);

    fetch("change_pic.php", {
        method: "POST",
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === "success") {
            // update image instantly
            profilePic.src = data.path + "?t=" + new Date().getTime();
            fileInput.value = ""; // allow same file again
        } else {
            alert(data.message);
        }
    })
    .catch(() => {
        alert("Upload failed. Please try again.");
    });
});
</script>




</body>
</html>
