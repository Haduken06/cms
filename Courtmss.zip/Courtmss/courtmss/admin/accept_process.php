<?php
include "../db_connect.php";
include "../email_notifier.php";

$reservation_id = $_GET['id'];

// START TRANSACTION
$conn->begin_transaction();

try {

    // 1️⃣ GET RESERVATION DATA
    $get = $conn->prepare("SELECT * FROM reservations WHERE reservation_id = ?");
    $get->bind_param("i", $reservation_id);
    $get->execute();
    $result = $get->get_result();

    if ($result->num_rows === 0) {
        throw new Exception("Reservation not found");
    }

    $row = $result->fetch_assoc();

    // 2️⃣ INSERT INTO ACCEPTED BOOKINGS
    $insert = $conn->prepare("
        INSERT INTO accepted_bookings
        (reservation_id, username, fullname, email, phonenumber, court_type, date, time_slot, status, users_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Accepted', ?)
    ");

    $insert->bind_param(
        "isssssssi",
        $row['reservation_id'],
        $row['username'],
        $row['fullname'],
        $row['email'],
        $row['phonenumber'],
        $row['court_type'],
        $row['date'],
        $row['time_slot'],
        $row['users_id']
    );
    $insert->execute();

    // 3️⃣ DELETE FROM PENDING RESERVATIONS
    $delete = $conn->prepare("DELETE FROM reservations WHERE reservation_id = ?");
    $delete->bind_param("i", $reservation_id);
    $delete->execute();

    // 4️⃣ COMMIT DATABASE CHANGES
    $conn->commit();

    // 5️⃣ SEND EMAIL (AFTER SUCCESS)
    sendReservationEmail(
        $row['email'],
        $row['fullname'],
        'ACCEPTED',
        $row
    );

    header("Location: reservations.php?accepted=success");

} catch (Exception $e) {
    $conn->rollback();
    echo "Error: " . $e->getMessage();
}
?>
