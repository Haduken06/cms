<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .form-container {
            background: #1a1a1a;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(255, 107, 0, 0.3);
            overflow: hidden;
            max-width: 450px;
            width: 100%;
            position: relative;
            border: 1px solid #2a2a2a;
        }

        .form-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 5px;
            background: linear-gradient(90deg, #ff6b00, #ff8c00, #ff6b00);
        }

        .container-inside {
            padding: 50px 40px;
        }

        h2 {
            color: #ff6b00;
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 10px;
            text-align: center;
            letter-spacing: -0.5px;
            text-shadow: 0 0 20px rgba(255, 107, 0, 0.3);
        }

        .subtitle {
            color: #999999;
            text-align: center;
            margin-bottom: 35px;
            font-size: 14px;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 18px;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 15px 20px;
            border: 2px solid #2a2a2a;
            border-radius: 10px;
            font-size: 15px;
            transition: all 0.3s ease;
            background: #0f0f0f;
            color: #ffffff;
        }

        input[type="text"]:focus,
        input[type="email"]:focus,
        input[type="password"]:focus {
            outline: none;
            border-color: #ff6b00;
            background: #1a1a1a;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(255, 107, 0, 0.2);
        }

        input::placeholder {
            color: #666666;
        }

        input[type="submit"] {
            background: linear-gradient(135deg, #ff6b00 0%, #ff8c00 100%);
            color: #000000;
            border: none;
            padding: 16px;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
            box-shadow: 0 5px 20px rgba(255, 107, 0, 0.3);
        }

        input[type="submit"]:hover {
            background: linear-gradient(135deg, #ff8c00 0%, #ffa500 100%);
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(255, 107, 0, 0.5);
        }

        input[type="submit"]:active {
            transform: translateY(0);
        }

        p {
            text-align: center;
            margin-top: 25px;
            color: #999999;
            font-size: 14px;
        }

        a {
            color: #ff6b00;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            position: relative;
        }

        a::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 0;
            height: 2px;
            background: #ff6b00;
            transition: width 0.3s ease;
        }

        a:hover {
            color: #ff8c00;
        }

        a:hover::after {
            width: 100%;
        }

        .message {
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
            font-size: 14px;
            font-weight: 500;
        }

        .success {
            background: rgba(255, 107, 0, 0.1);
            color: #ff6b00;
            border: 2px solid #ff6b00;
        }

        .error {
            background: rgba(255, 107, 0, 0.05);
            color: #ff8c00;
            border: 2px solid #ff8c00;
        }

        @media (max-width: 480px) {
            .container-inside {
                padding: 40px 30px;
            }

            h2 {
                font-size: 28px;
            }

            input[type="text"],
            input[type="email"],
            input[type="password"] {
                padding: 13px 18px;
            }
        }
    </style>
</head>
<body>
    <div class="form-container">
        <div class="container-inside">
            <h2>Register</h2>
            <p class="subtitle">Create your account to get started</p>
            
            <!-- PHP messages would appear here -->
            <!-- <div class="message success">Success</div> -->
            <!-- <div class="message error">Password does not match</div> -->
            
            <form action="register.php" method="POST">
                <input type="text" name="username" placeholder="Username" required>
                <input type="text" name="fullname" placeholder="Full Name" required>
                <input type="email" name="email" placeholder="Email Address" required>
                <input type="text" name="phonenumber" placeholder="Phone Number" required>
                <input type="password" name="password" placeholder="Password" required>
                <input type="password" name="confirmPassword" placeholder="Confirm Password" required>
                <input type="submit" value="Register">
                <p>Already have an account? <a href="../index.php">Log In</a></p>
            </form>
        </div>
    </div>
</body>
</html>