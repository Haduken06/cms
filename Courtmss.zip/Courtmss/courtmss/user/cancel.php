<?php
include "../db_connect.php";

$reservation_id = $_GET['id'];

$conn->begin_transaction();

try{
    $get = $conn->prepare("SELECT * FROM reservations WHERE reservation_id = ?");
    $get->bind_param("i", $reservation_id);
    $get->execute();
    $result = $get->get_result();

    if($result->num_rows === 0){
        throw new Exception("Reservation not found");
    }

    $row = $result->fetch_assoc();
    $insert = $conn->prepare("INSERT INTO cancelled_bookings (reservation_id, username, fullname, email, phonenumber, court_type, date, time_slot, status, users_id)
        VALUES (?,?,?,?,?,?,?,?, 'Cancelled', ?)");

    $insert->bind_param("isssssssi", 
        $row['reservation_id'],
        $row['username'],
        $row['fullname'],
        $row['email'],
        $row['phonenumber'],
        $row['court_type'],
        $row['date'],
        $row['time_slot'],
        $row['users_id']);

        $insert->execute();
    
        $update = $conn->prepare("UPDATE reservations SET status = 'Cancelled' where reservation_id = ?");
        
        $update->bind_param("i", $reservation_id);
        $update->execute();

        $delete = $conn->prepare("DELETE FROM reservations WHERE reservation_id = ?");
        $delete->bind_param("i", $reservation_id);
        $delete->execute();

        $conn->commit();
        echo "Reservation Cancelled";
}catch (Exception $e){
        $conn->rollback();
    echo "Error: " . $e->getMessage();
}