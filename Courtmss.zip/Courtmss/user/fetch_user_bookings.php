<?php
include "../db_connect.php";

header('Content-Type: application/json');

if (!isset($_GET['code'])) {
    echo json_encode([]);
    exit;
}

$code = trim($_GET['code']);

// Validate booking code (6 digits)
if (strlen($code) !== 6) {
    echo json_encode([]);
    exit;
}

// Prepared statement
$sql = "SELECT 
            reservation_id,
            fullname,
            email,
            phonenumber,
            purpose,
            date,
            start_time,
            end_time,
            booking_code,
            status
        FROM reservations
        WHERE booking_code = ?
        ORDER BY date DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $code);
$stmt->execute();

$result = $stmt->get_result();
$bookings = [];

while ($row = $result->fetch_assoc()) {
    $bookings[] = $row;
}

echo json_encode($bookings);

$stmt->close();
$conn->close();
