<?php
include "../db_connect.php";
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["success" => false, "message" => "Invalid request method"]);
    exit;
}

if (!isset($_POST['id'])) {
    echo json_encode(["success" => false, "message" => "Reservation ID required"]);
    exit;
}

$reservation_id = intval($_POST['id']);

$conn->begin_transaction();

try {
    $insert = "
        INSERT INTO cancelled_bookings
        SELECT * FROM reservations
        WHERE reservation_id = ?
          AND (LOWER(status) = 'pending' OR LOWER(status) = 'active')
    ";

    $stmt = $conn->prepare($insert);
    $stmt->bind_param("i", $reservation_id);
    $stmt->execute();

    if ($stmt->affected_rows === 0) {
        throw new Exception("Booking cannot be cancelled");
    }

    $update = "
        UPDATE cancelled_bookings
        SET status = 'cancelled'
        WHERE reservation_id = ?
    ";
    $stmt = $conn->prepare($update);
    $stmt->bind_param("i", $reservation_id);
    $stmt->execute();

    $delete = "DELETE FROM reservations WHERE reservation_id = ?";
    $stmt = $conn->prepare($delete);
    $stmt->bind_param("i", $reservation_id);
    $stmt->execute();

    $conn->commit();

    echo json_encode([
        "success" => true,
        "message" => "Booking cancelled successfully"
    ]);

} catch (Exception $e) {
    $conn->rollback();
    echo json_encode([
        "success" => false,
        "message" => $e->getMessage()
    ]);
}

$conn->close();
