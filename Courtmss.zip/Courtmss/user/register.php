<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .form-container {
            background: rgba(52, 73, 94, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(93, 156, 236, 0.3);
            overflow: hidden;
            max-width: 450px;
            width: 100%;
            position: relative;
            border: 1px solid rgba(255, 255, 255, 0.15);
        }

        .form-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 5px;
            background: linear-gradient(90deg, #5d9cec, #4a89dc, #5d9cec);
        }

        .container-inside {
            padding: 50px 40px;
        }

        h2 {
            color: #5d9cec;
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 10px;
            text-align: center;
            letter-spacing: -0.5px;
            text-shadow: 0 0 20px rgba(93, 156, 236, 0.3);
        }

        .subtitle {
            color: #bdc3c7;
            text-align: center;
            margin-bottom: 35px;
            font-size: 14px;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 18px;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 15px 20px;
            border: 2px solid rgba(255, 255, 255, 0.15);
            border-radius: 10px;
            font-size: 15px;
            transition: all 0.3s ease;
            background: rgba(255, 255, 255, 0.08);
            color: #ffffff;
        }

        input[type="text"]:focus,
        input[type="email"]:focus,
        input[type="password"]:focus {
            outline: none;
            border-color: #5d9cec;
            background: rgba(255, 255, 255, 0.1);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(93, 156, 236, 0.2);
        }

        input::placeholder {
            color: #bdc3c7;
        }

        input[type="submit"] {
            background: linear-gradient(135deg, #5d9cec 0%, #4a89dc 100%);
            color: #ffffff;
            border: none;
            padding: 16px;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
            box-shadow: 0 5px 20px rgba(93, 156, 236, 0.3);
        }

        input[type="submit"]:hover {
            background: linear-gradient(135deg, #4a89dc 0%, #357abd 100%);
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(93, 156, 236, 0.5);
        }

        input[type="submit"]:active {
            transform: translateY(0);
        }

        p {
            text-align: center;
            margin-top: 25px;
            color: #bdc3c7;
            font-size: 14px;
        }

        a {
            color: #5d9cec;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            position: relative;
        }

        a::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 0;
            height: 2px;
            background: #5d9cec;
            transition: width 0.3s ease;
        }

        a:hover {
            color: #48cfad;
        }

        a:hover::after {
            width: 100%;
        }

        .message {
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
            font-size: 14px;
            font-weight: 500;
        }

        .success {
            background: rgba(72, 207, 173, 0.1);
            color: #48cfad;
            border: 2px solid #48cfad;
        }

        .error {
            background: rgba(93, 156, 236, 0.1);
            color: #5d9cec;
            border: 2px solid #5d9cec;
        }

        @media (max-width: 480px) {
            .container-inside {
                padding: 40px 30px;
            }

            h2 {
                font-size: 28px;
            }

            input[type="text"],
            input[type="email"],
            input[type="password"] {
                padding: 13px 18px;
            }
        }
    </style>
</head>
<body>
    <div class="form-container">
        <div class="container-inside">
            <h2>Register</h2>
            <p class="subtitle">Create your account to get started</p>
            
            <!-- PHP messages would appear here -->
            <!-- <div class="message success">Success</div> -->
            <!-- <div class="message error">Password does not match</div> -->
            
            <form action="register.php" method="POST">
                <input type="text" name="username" placeholder="Username" required>
                <input type="text" name="fullname" placeholder="Full Name" required>
                <input type="email" name="email" placeholder="Email Address" required>
                <input type="text" name="phonenumber" placeholder="Phone Number" required>
                <input type="password" name="password" placeholder="Password" required>
                <input type="password" name="confirmPassword" placeholder="Confirm Password" required>
                <input type="submit" value="Register">
                <p>Already have an account? <a href="../index.php">Log In</a></p>
            </form>
        </div>
    </div>
</body>
</html>