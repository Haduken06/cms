<?php
include "../db_connect.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>View My Bookings</title>

  <style>
    body{
      font-family:Arial,Helvetica,sans-serif;
      background:#f5f5f5;
      margin:0;
      padding:0
    }
    header{
      background:#333;
      color:#fff;
      padding:12px;
      text-align:center
    }
    .container{
      max-width:700px;
      margin:30px auto;
      background:#fff;
      padding:20px;
      border-radius:12px;
      box-shadow:0 4px 10px rgba(0,0,0,.15)
    }
    .form-group{
      margin-bottom:15px
    }
    input{
      width:100%;
      padding:10px;
      font-size:16px;
      border:1px solid #ccc;
      border-radius:6px
    }
    button{
      padding:10px 16px;
      border:none;
      border-radius:6px;
      background:#007bff;
      color:#fff;
      cursor:pointer;
      font-size:15px
    }
    button.cancel{
      background:#dc3545
    }
    button:hover{
      opacity:.9
    }
    table{
      width:100%;
      border-collapse:collapse;
      margin-top:20px
    }
    th,td{
      border:1px solid #ddd;
      padding:8px;
      text-align:center;
      font-size:14px
    }
    th{
      background:#007bff;
      color:#fff
    }
    .no-booking{
      text-align:center;
      margin-top:15px;
      color:#555
    }
    .anchor{
      position:absolute;
      left:15px;
      top:15px;
      background:#fff;
      color:#000;
      text-decoration:none;
      padding:6px 10px;
      border-radius:50%;
      font-weight:bold
    }
  </style>
</head>
<body>

<header>
  <a href="../index.php" class="anchor"><</a>
  <h1>View My Bookings</h1>
</header>

<div class="container">
  <div class="form-group">
    <label>Enter your 6-digit Booking Code</label>
    <input type="text" id="bookingCode" maxlength="6" placeholder="e.g. 123456">
  </div>

  <button id="viewBtn">View My Bookings</button>

  <div id="results"></div>
</div>

<script>
document.getElementById('viewBtn').addEventListener('click', function () {
  const code = document.getElementById('bookingCode').value.trim();
  const results = document.getElementById('results');

  if (!code || code.length !== 6) {
    alert('Please enter a valid 6-digit booking code.');
    return;
  }

  results.innerHTML = "<p>Loading...</p>";

  fetch('fetch_user_bookings.php?code=' + encodeURIComponent(code))
    .then(res => res.json())
    .then(data => {
      if (!Array.isArray(data) || data.length === 0) {
        results.innerHTML = "<p class='no-booking'>No bookings found.</p>";
        return;
      }

      let html = `
        <table>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Date</th>
            <th>Time</th>
            <th>Purpose</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
      `;

      data.forEach(row => {
        html += `
          <tr>
            <td>${escapeHtml(row.fullname)}</td>
            <td>${escapeHtml(row.email)}</td>
            <td>${escapeHtml(row.phonenumber)}</td>
            <td>${escapeHtml(row.date)}</td>
            <td>${formatTime(row.start_time)} - ${formatTime(row.end_time)}</td>
            <td>${escapeHtml(row.purpose)}</td>
            <td>${escapeHtml(row.status)}</td>
            <td>
              ${row.status.toLowerCase() === 'pending' || row.status.toLowerCase() === 'active'
                ? `<button class="cancel" onclick="cancelBooking(${row.reservation_id})">Cancel</button>`
                : '-'}
            </td>
          </tr>
        `;
      });

      html += `</table>`;
      results.innerHTML = html;
    })
    .catch(err => {
      console.error(err);
      results.innerHTML = "<p style='color:red;'>Failed to load bookings.</p>";
    });
});

function cancelBooking(id) {
  if (!confirm('Are you sure you want to cancel this booking?')) return;

  fetch('cancel.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'id=' + encodeURIComponent(id)
  })
  .then(res => res.json())
  .then(data => {
    alert(data.message);
    document.getElementById('viewBtn').click(); // refresh
  })
  .catch(err => {
    alert('Failed to cancel booking.');
    console.error(err);
  });
}

function formatTime(time) {
  if (!time) return '';
  const [h, m] = time.split(':');
  let hour = parseInt(h);
  const ampm = hour >= 12 ? 'PM' : 'AM';
  hour = hour % 12 || 12;
  return `${hour}:${m} ${ampm}`;
}

function escapeHtml(s) {
  return String(s)
    .replaceAll('&','&amp;')
    .replaceAll('<','&lt;')
    .replaceAll('>','&gt;')
    .replaceAll('"','&quot;')
    .replaceAll("'",'&#039;');
}
</script>

</body>
</html>
