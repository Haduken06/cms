<?php
include "../db_connect.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    exit('Invalid access method.');
}

$fullname     = trim($_POST['fullname'] ?? '');
$email        = trim($_POST['email'] ?? '');
$phonenumber  = trim($_POST['phonenumber'] ?? '');
$purpose      = trim($_POST['purpose'] ?? '');
$date         = $_POST['date'] ?? '';
$start_time   = $_POST['start_time'] ?? '';
$end_time     = $_POST['end_time'] ?? '';
$booking_code = trim($_POST['booking_code'] ?? '');
$status       = "PENDING";
$created_at   = date("Y-m-d H:i:s");

// Basic validation
if (
    empty($fullname) ||
    empty($phonenumber) ||
    empty($date) ||
    empty($start_time) ||
    empty($end_time)
) {
    die("Required fields missing.");
}

if ($start_time >= $end_time) {
    die("End time must be later than start time.");
}

$today = date("Y-m-d");
if ($date < $today) {
    die("You cannot book a past date.");
}

// Check conflict in PENDING reservations
$check1 = $conn->prepare("
    SELECT COUNT(*) AS total
    FROM reservations
    WHERE date = ?
      AND status != 'CANCELLED'
      AND start_time < ?
      AND end_time > ?
");
$check1->bind_param("sss", $date, $end_time, $start_time);
$check1->execute();
$res1 = $check1->get_result()->fetch_assoc();
$check1->close();


// Check conflict in ACCEPTED bookings
$check2 = $conn->prepare("
    SELECT COUNT(*) AS total
    FROM accepted_bookings
    WHERE date = ?
      AND start_time < ?
      AND end_time > ?
");
$check2->bind_param("sss", $date, $end_time, $start_time);
$check2->execute();
$res2 = $check2->get_result()->fetch_assoc();
$check2->close();

if ($res1['total'] > 0 || $res2['total'] > 0) {
    die("This time range is already booked.");
}


$stmt = $conn->prepare("
    INSERT INTO reservations
    (fullname, email, phonenumber, purpose, date, start_time, end_time, status, created_at, booking_code)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
");

if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}

$stmt->bind_param(
    "ssssssssss",
    $fullname,
    $email,
    $phonenumber,
    $purpose,
    $date,
    $start_time,
    $end_time,
    $status,
    $created_at,
    $booking_code
);

if ($stmt->execute()) {
    echo "Booking successful! Your booking code is: " . htmlspecialchars($booking_code);
} else {
    echo "Error saving booking: " . $stmt->error;
}

$stmt->close();
$conn->close();
