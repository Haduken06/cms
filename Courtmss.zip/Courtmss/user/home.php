<?php
    session_start();
    include "../db_connect.php";

    if(!isset($_SESSION['username'])){
        header("Location: ../index.php");
        exit();
    }

    $username = $_SESSION['username'];

    $sql = "SELECT reservation_id, username, fullname, email, phonenumber, court_type, date, time_slot, created_at, status
    FROM reservations
    WHERE username = ? AND status = 'pending'
    
    UNION

    SELECT reservation_id, username, fullname, email, phonenumber, court_type, date, time_slot, accepted_at, status
    FROM accepted_bookings
    WHERE username = ?
    
    UNION

    SELECT reservation_id, username, fullname, email, phonenumber, court_type, date, time_slot, denied_at, status
    FROM denied_bookings
    WHERE username = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $username, $username, $username);
    $stmt->execute();
    $result = $stmt->get_result();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200&icon_names=menu" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <title>Home</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary-color: #5d9cec;
            --secondary-color: #4a89dc;
            --accent-color: #48cfad;
            --dark-bg: #2c3e50;
            --card-bg: #34495e;
            --light-bg: #ecf0f1;
            --text-primary: #ffffff;
            --text-secondary: #bdc3c7;
            --glass-bg: rgba(255, 255, 255, 0.08);
            --shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
            --border-color: rgba(255, 255, 255, 0.15);
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 50%, #2c3e50 100%);
            min-height: 100vh;
            color: var(--text-primary);
            line-height: 1.6;
        }

        /* Navigation Styles */
        .nav-bar {
            background: rgba(44, 62, 80, 0.95);
            backdrop-filter: blur(20px);
            border-bottom: 2px solid var(--primary-color);
            padding: 1rem 2rem;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 20px rgba(93, 156, 236, 0.2);
            transition: all 0.3s ease;
        }

        .nav-bar:hover {
            box-shadow: 0 8px 32px rgba(93, 156, 236, 0.3);
        }

        .logo img {
            height: 50px;
            width: auto;
            transition: transform 0.3s ease;
            filter: drop-shadow(0 2px 4px rgba(93, 156, 236, 0.3));
        }

        .logo:hover img {
            transform: scale(1.05);
        }

        .align-right {
            display: flex;
            align-items: center;
            gap: 2rem;
        }

        .nav-links {
            display: flex;
            list-style: none;
            gap: 2rem;
            align-items: center;
        }

        .nav-links a {
            text-decoration: none;
            color: var(--text-primary);
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 25px;
            transition: all 0.3s ease;
            position: relative;
        }

        .nav-links a::after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            background: var(--primary-color);
            transition: width 0.3s ease;
        }

        .nav-links a:hover {
            color: var(--primary-color);
            transform: translateY(-2px);
        }

        .nav-links a:hover::after {
            width: 80%;
        }

        /* Dropdown Styles */
        .dropdown {
            position: relative;
        }

        .menu-btn {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            border: none;
            padding: 0.75rem;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(93, 156, 236, 0.3);
        }

        .menu-btn:hover {
            transform: scale(1.1) rotate(90deg);
            box-shadow: 0 6px 25px rgba(93, 156, 236, 0.5);
        }

        .content-dropdown {
            display: none;
            position: absolute;
            top: 120%;
            right: 0;
            background: var(--card-bg);
            backdrop-filter: blur(20px);
            border-radius: 12px;
            padding: 0.75rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            border: 1px solid var(--border-color);
            animation: slideDown 0.3s ease;
            min-width: 140px;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .logoutBtn {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            border: none;
            padding: 0.65rem 1.3rem;
            border-radius: 20px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s ease;
            box-shadow: 0 3px 10px rgba(93, 156, 236, 0.3);
            width: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }

        .logoutBtn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(93, 156, 236, 0.5);
        }

        /* Announcements Box */
        .box {
            background: var(--card-bg);
            margin-top: 100px;
            padding: 2rem;
            margin-left: 2rem;
            margin-right: 2rem;
            border-radius: 15px;
            border: 1px solid var(--border-color);
            box-shadow: var(--shadow);
            animation: fadeInUp 0.6s ease;
        }

        .box h1 {
            color: var(--primary-color);
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 1.8rem;
        }

        .box h1 i {
            font-size: 1.6rem;
        }

        .box p {
            color: var(--text-secondary);
            line-height: 1.8;
        }

        /* Home Section Styles */
        #home {
            margin-top: 2rem;
            padding: 2rem;
        }

        .sections {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
            max-width: 1400px;
            margin: 0 auto;
            animation: fadeInUp 0.8s ease;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .section2, .section1 {
            background: var(--card-bg);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            padding: 2.5rem;
            box-shadow: var(--shadow);
            border: 1px solid var(--border-color);
            transition: all 0.3s ease;
        }

        .section2:hover, .section1:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 40px rgba(93, 156, 236, 0.2);
        }

        .section2 h2 {
            font-size: 2rem;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .section2 h2 i {
            color: var(--primary-color);
        }

        .section2 h4 {
            font-size: 1.3rem;
            font-weight: 600;
            color: var(--accent-color);
            margin-bottom: 1rem;
            margin-top: 1.5rem;
        }

        .section2 hr {
            border: none;
            height: 2px;
            background: linear-gradient(90deg, var(--primary-color), var(--accent-color));
            border-radius: 2px;
            margin: 1rem 0;
        }

        .section1 h1 {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--text-primary);
            text-align: center;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.75rem;
        }

        .section1 h1 i {
            color: var(--primary-color);
        }

        .section1 hr {
            border: none;
            height: 2px;
            background: linear-gradient(90deg, var(--primary-color), var(--accent-color));
            border-radius: 2px;
            margin: 1rem 0;
        }

        .section1 p {
            font-size: 1rem;
            color: var(--text-secondary);
            line-height: 1.8;
            text-align: justify;
        }

        /* Table Styles */
        #table {
            margin-top: 1.5rem;
        }

        .table {
            width: 100%;
            background: rgba(0, 0, 0, 0.2);
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            border: 1px solid var(--border-color);
        }

        .table th {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            font-weight: 600;
            padding: 1rem;
            text-align: left;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .table td {
            padding: 1rem;
            border-bottom: 1px solid var(--border-color);
            font-weight: 400;
            transition: all 0.3s ease;
            color: var(--text-primary);
        }

        .table tr:nth-child(even) td {
            background: rgba(93, 156, 236, 0.05);
        }

        .table tr:hover td {
            background: rgba(93, 156, 236, 0.15);
        }

        .table tr:last-child td {
            border-bottom: none;
        }

        /* Button Styles */
        .btn {
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 20px;
            text-decoration: none;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-danger {
            background: linear-gradient(135deg, #e74c3c, #c0392b);
            color: white;
            box-shadow: 0 3px 10px rgba(231, 76, 60, 0.3);
        }

        .btn-danger:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(231, 76, 60, 0.5);
        }

        /* Court Section Styles */
        #court {
            padding: 4rem 2rem;
            text-align: center;
        }

        .section-heading {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 1rem;
            position: relative;
            display: inline-flex;
            align-items: center;
            gap: 0.75rem;
        }

        .section-heading i {
            color: var(--primary-color);
        }

        .section-heading::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 100px;
            height: 3px;
            background: linear-gradient(90deg, var(--primary-color), var(--accent-color));
            border-radius: 2px;
        }

        .court-section {
            position: relative;
            max-width: 1000px;
            margin: 2rem auto 0;
            background: var(--card-bg);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            padding: 2rem;
            box-shadow: var(--shadow);
            border: 1px solid var(--border-color);
        }

        .slider {
            position: relative;
            width: 100%;
            height: 500px;
            overflow: hidden;
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
        }

        .slider img {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            opacity: 0;
            transition: opacity 0.8s ease-in-out;
        }

        .slider img.displaySlide {
            opacity: 1;
        }

        .prev, .next {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background: rgba(93, 156, 236, 0.9);
            color: white;
            border: none;
            width: 45px;
            height: 45px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            cursor: pointer;
            border-radius: 50%;
            transition: all 0.3s ease;
            z-index: 10;
            box-shadow: 0 4px 15px rgba(93, 156, 236, 0.4);
        }

        .prev {
            left: 20px;
        }

        .next {
            right: 20px;
        }

        .prev:hover, .next:hover {
            background: var(--primary-color);
            transform: translateY(-50%) scale(1.15);
            box-shadow: 0 6px 20px rgba(93, 156, 236, 0.6);
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .sections {
                grid-template-columns: 1fr;
                gap: 2rem;
            }

            .section2, .section1 {
                padding: 2rem;
            }
        }

        @media (max-width: 768px) {
            .nav-links {
                display: none;
            }

            .nav-bar {
                padding: 1rem;
            }

            .box {
                margin-left: 1rem;
                margin-right: 1rem;
                margin-top: 90px;
            }

            #home {
                padding: 1rem;
                margin-top: 1.5rem;
            }

            .sections {
                gap: 1.5rem;
            }

            .section2, .section1 {
                padding: 1.5rem;
            }

            .section2 h2 {
                font-size: 1.6rem;
            }

            .section1 h1 {
                font-size: 1.5rem;
            }

            .section-heading {
                font-size: 2rem;
            }

            .slider {
                height: 350px;
            }

            .prev, .next {
                width: 38px;
                height: 38px;
                font-size: 1rem;
            }

            .prev {
                left: 10px;
            }

            .next {
                right: 10px;
            }
        }

        @media (max-width: 480px) {
            .box {
                padding: 1.5rem;
            }

            .box h1 {
                font-size: 1.4rem;
            }

            .section2 h2 {
                font-size: 1.4rem;
            }

            .section1 h1 {
                font-size: 1.3rem;
            }

            .section-heading {
                font-size: 1.8rem;
            }

            .table {
                font-size: 0.85rem;
            }

            .table th,
            .table td {
                padding: 0.75rem 0.5rem;
            }

            .slider {
                height: 280px;
            }
        }

        /* Loading Animations */
        .section2 {
            animation: slideInLeft 0.8s ease;
        }

        .section1 {
            animation: slideInRight 0.8s ease;
        }

        @keyframes slideInLeft {
            from {
                opacity: 0;
                transform: translateX(-50px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        @keyframes slideInRight {
            from {
                opacity: 0;
                transform: translateX(50px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        /* Scrollbar Styling */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: rgba(44, 62, 80, 0.8);
        }

        ::-webkit-scrollbar-thumb {
            background: linear-gradient(135deg, var(--primary-color), var(--accent-color));
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(135deg, var(--secondary-color), var(--primary-color));
        }

        /* Status badges */
        .status-badge {
            padding: 0.3rem 0.8rem;
            border-radius: 15px;
            font-size: 0.85rem;
            font-weight: 600;
            display: inline-block;
        }

        .status-pending {
            background: rgba(241, 196, 15, 0.2);
            color: #f1c40f;
            border: 1px solid rgba(241, 196, 15, 0.3);
        }

        .status-accepted {
            background: rgba(72, 207, 173, 0.2);
            color: var(--accent-color);
            border: 1px solid rgba(72, 207, 173, 0.3);
        }

        .status-denied {
            background: rgba(231, 76, 60, 0.2);
            color: #e74c3c;
            border: 1px solid rgba(231, 76, 60, 0.3);
        }
    </style>
</head>
<body>
    <div class="#top"></div>
    <header class="nav-bar">
        <div class="logo"><a href="#top"><img src="assets/imgs/seal.png" alt="seal"></a></div>
        <div class="align-right">
            <ul class="nav-links">
                <li><a href="#top">Home</a></li>
                <li><a href="booking.php">Book Now</a></li>
                <li><a href="home.php#court">View Court</a></li>
            </ul>
            <div class="dropdown">
                <button id="menuBtn" class="menu-btn"><span class="material-symbols-outlined">menu</span></button>
                <div class="content-dropdown">                                               
                    <a href="../logout.php"><button class="logoutBtn"><i class="fas fa-sign-out-alt"></i> Log out</button></a>
                </div>
            </div>
        </div>
    </header>

    <section id="home">
        <div class="sections">
            <div class="section2">
                <h2><i class="fas fa-user-circle"></i> Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h2>
                <h4>Your Bookings</h4>
                <hr>
                <div id="table">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Full Name</th>
                                <th>Court Type</th>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['fullname']); ?></td>
                                    <td><?php echo htmlspecialchars($row['court_type']); ?></td>
                                    <td><?php echo htmlspecialchars(date("F j, Y", strtotime($row['date']))); ?></td>
                                    <td><?php echo htmlspecialchars($row['time_slot']); ?></td>
                                    <td>
                                        <?php 
                                        $status = strtolower($row['status']);
                                        $statusClass = 'status-' . $status;
                                        ?>
                                        <span class="status-badge <?php echo $statusClass; ?>">
                                            <?php echo htmlspecialchars(ucfirst($row['status'])); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($row['status'] === 'PENDING' || $row['status'] === 'pending'): ?>
                                            <a href="cancel.php?id=<?php echo $row['reservation_id']; ?>" 
                                            class="btn btn-sm btn-danger"
                                            onclick="return confirm('Are you sure you want to cancel this booking?');">
                                                <i class="fas fa-times-circle"></i> Cancel
                                            </a>
                                        <?php else: ?>
                                            <span style="color: var(--text-secondary);">N/A</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="section1">
                <h1><i class="fas fa-info-circle"></i> Introduction</h1>
                <hr>
                <p>Brgy Ermita, Cebu is an organized way for residents to book and use sports courts such as basketball or volleyball courts.
                     This system helps manage the schedule by allowing people to reserve courts ahead of time, ensuring fair access and reducing conflicts.
                    It can be done manually through barangay offices or digitally via an online platform, making it easier for the community to enjoy sports facilities conveniently and efficiently.
                     This initiative promotes active lifestyles and community engagement in Brgy Ermita.
                </p>
            </div>
        </div>
    </section>

    <section id="court">
        <h1 class="section-heading"><i class="fas fa-basketball-ball"></i> View Court</h1>
        <div class="court-section">
            <div class="slider">
                <img src="assets/imgs/guada_court1.jpg" alt="guada_court1">
                <img src="assets/imgs/guada_court2.jpg" alt="guada_court2">
                <img src="assets/imgs/guada_court3.jpg" alt="guada_court3">
            </div>       
            <button class="prev" id="prev">&#10094</button>
            <button class="next" id="next">&#10095</button>         
        </div>
    </section>

    <script>
        //For Image Slider
        const slides = document.querySelectorAll(".slider img");
        let slideIndex = 0;
        let intervalId = null;

        document.addEventListener("DOMContentLoaded", initializeSlider)
        function initializeSlider(){
            if(slides.length > 0){
                slides[slideIndex].classList.add("displaySlide");
                intervalId = setInterval(nextSlide, 3000);
            }
        }
        function showSlide(index){
            if(index >= slides.length){
                slideIndex = 0;
            }else if(index < 0){
                slideIndex = slides.length - 1;
            }
            slides.forEach(slide => {
                slide.classList.remove("displaySlide");
            });
            slides[slideIndex].classList.add("displaySlide");
        }

        //prev btn
        const prevBtn = document.getElementById("prev");
        prevBtn.addEventListener("click", prevSlide);
        function prevSlide(){
            clearInterval(intervalId);
            slideIndex--;
            showSlide(slideIndex);
        }

        //next btn
        const nextBtn = document.getElementById("next");
        nextBtn.addEventListener("click", nextSlide);
        function nextSlide(){
            slideIndex++;
            showSlide(slideIndex);
        }

        // click drop down menu
        const menuBtn = document.getElementById("menuBtn");
        const dropdown = document.querySelector(".content-dropdown");
        menuBtn.addEventListener("click", () => {
            dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
        });

        // Close dropdown when clicking outside
        window.addEventListener("click", (e) => {
            if (!e.target.closest('.dropdown')) {
                dropdown.style.display = "none";
            }
        });
    </script>

</body>
</html>