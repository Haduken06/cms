<?php
session_start();
include_once "../db_connect.php";

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$conn->set_charset('utf8mb4');

header('Content-Type: application/json; charset=utf-8');

try {

$isLoggedIn = isset($_SESSION['username']) && !empty($_SESSION['username']);

if(!empty($_GET['date'])){

$date=$_GET['date'];

$d=DateTime::createFromFormat('Y-m-d',$date);
if(!$d || $d->format('Y-m-d')!==$date){
echo json_encode([]);
exit;
}

$sql="
SELECT fullname,time_slot AS time,UPPER(status) AS status
FROM reservations
WHERE date=?

UNION ALL

SELECT fullname,time_slot AS time,'ACCEPTED' AS status
FROM accepted_bookings
WHERE date=?

ORDER BY STR_TO_DATE(SUBSTRING_INDEX(time,' - ',1),'%H:%i')
";

$stmt=$conn->prepare($sql);
$stmt->bind_param("ss",$date,$date);
$stmt->execute();
$res=$stmt->get_result();

$data=[];
while($row=$res->fetch_assoc()){
if(!$isLoggedIn){
$row['fullname']="Login to view";
}
$data[]=$row;
}

echo json_encode($data);
exit;
}

$sql="
SELECT date,COUNT(*) total FROM(
SELECT date FROM reservations
UNION ALL
SELECT date FROM accepted_bookings
)t GROUP BY date
";

$res=$conn->query($sql);

$events=[];
while($r=$res->fetch_assoc()){
$events[]=[
'title'=>$r['total'].' booking(s)',
'start'=>$r['date'],
'allDay'=>true,
'display'=>'background',
'color'=>'#ff6b35'
];
}

echo json_encode($events);

}catch(Throwable $e){
http_response_code(500);
echo json_encode(['error'=>true,'message'=>$e->getMessage()]);
}